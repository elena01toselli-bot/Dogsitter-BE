package com.progettodogsitting.dogsitting_backend.model;

import java.time.LocalDate;
import java.time.LocalTime;

import jakarta.persistence.*;
import lombok.Data;

// Mappa l'effettivo svolgimento del servizio legato a una prenotazione
@Data
@Entity
@Table(name = "esecuzione_servizio")
public class EsecuzioneServizio {

    // Chiave primaria coincidente col codice prenotazione
    @Id
    @Column(name = "codice_id_pren", nullable = false)
    private Integer codiceIdPren;

    // Orario in cui è stato completato il servizio
    @Column(name = "ora_svolgimento", nullable = false)
    private LocalTime oraSvolgimento;

    // Data in cui è stato completato il servizio
    @Column(name = "data_svolgimento", nullable = false)
    private LocalDate dataSvolgimento;

    // Relazione uno a uno con la prenotazione di origine
    @OneToOne
    @MapsId
    @JoinColumn(name = "codice_id_pren", insertable = false, updatable = false)
    private Prenotazione prenotazione;

    // Il servizio specifico eseguito (es. toelettatura)
    @ManyToOne
    @JoinColumn(name = "id_servizio", nullable = false)
    private Servizio servizio;

    // Il dogsitter che ha effettuato la prestazione
    @ManyToOne
    @JoinColumn(name = "username_d", nullable = false)
    private Dogsitter dogsitter;
}
