package com.progettodogsitting.dogsitting_backend.model;

import java.math.BigDecimal;


import jakarta.persistence.*;
import lombok.Data;

// Entità che rappresenta una singola prenotazione per cani o lezioni
@Data
@Entity
@Table(name = "prenotazione")
public class Prenotazione {

    // ID testuale generato univocamente
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    /* Nel database metti questo
    ALTER TABLE prenotazione 
    MODIFY codice_id INT AUTO_INCREMENT;
     */
    @Column(name = "codice_id", nullable = false)
    private Integer codiceId;   

    // Il costo accordato per la prestazione
    @Column(name = "prezzo_pattuito", nullable = false, precision = 10, scale = 2)
    private BigDecimal prezzoPattuito;

    // Tipo di prestazione (es. dog sitting, lezione di addestramento)
    @Column(name = "tipologia_attivita", nullable = false)
    private String tipologiaAttivita;


    // 
    // prenotazione.getLezione().getCampoAddestramento(); sempre disponibile
    @ManyToOne
    @JoinColumns({
        @JoinColumn(name = "nome_campo", referencedColumnName = "nome_campo"),
        @JoinColumn(name = "ora_lezione", referencedColumnName = "ora"),
        @JoinColumn(name = "data_lezione", referencedColumnName = "data")
    })
    private Lezione lezione;

    // Cane associato alla prenotazione
    @ManyToOne
    @JoinColumn(name = "n_microchip", nullable = false)
    private Cane cane;
}
