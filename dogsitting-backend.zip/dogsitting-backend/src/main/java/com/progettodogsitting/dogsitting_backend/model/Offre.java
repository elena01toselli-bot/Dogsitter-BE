package com.progettodogsitting.dogsitting_backend.model;

import java.math.BigDecimal;

import jakarta.persistence.*;
import lombok.Data;

// Entità che mappa la tabella ponte "offre" tra dogsitter e servizio
@Data
@Entity
@Table(name = "offre")
public class Offre {

    // Chiave primaria composta (username_d, id_servizio)
    @EmbeddedId
    private OffreId id;

    // Collegamento in sola lettura alla tabella dogsitter
    @ManyToOne
    // La colonna username_d è già gestita dal campo usernameDogsitter dentro OfferId 
    // — non creare una colonna separata, usa quella
    @MapsId("usernameDogsitter") // Associa questa relazione alla proprietà dell'ID composto
    @JoinColumn(name = "username_d")
    private Dogsitter dogsitter;

    // Collegamento in sola lettura alla tabella servizio
    @ManyToOne
    // La colonna id_servizio è già gestita dal campo idServizio dentro OfferId
    // — non creare una colonna separata, usa quella dice MapsId
    @MapsId("idServizio") // Associa questa relazione alla proprietà dell'ID composto
    @JoinColumn(name = "id_servizio")
    private Servizio servizio;

    // Prezzo fissato dal dogsitter per questo servizio
    @Column(name = "prezzo_listino",precision = 10, scale = 2)
    private BigDecimal prezzoListino;
}
