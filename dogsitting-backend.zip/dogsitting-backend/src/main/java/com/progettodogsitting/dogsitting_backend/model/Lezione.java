package com.progettodogsitting.dogsitting_backend.model;

import jakarta.persistence.*;
import lombok.Data;


@Data
@Entity
@Table(name = "lezione")
public class Lezione {


    @EmbeddedId
    private LezioneId id;

    @Column(name = "max_partecipanti", nullable = false)
    private Integer maxPartecipanti;

    // nome_campo è sia parte della PK che FK verso CampoAddestramento
    @ManyToOne
    @MapsId("nomeCampo")
    @JoinColumn(name = "nome_campo")
    private CampoAddestramento campoAddestramento;

    // tipologia è solo FK, non fa parte della PK
    @ManyToOne
    @JoinColumn(name = "tipologia", nullable = false)
    private TipologiaLezione tipologiaLezione;
}