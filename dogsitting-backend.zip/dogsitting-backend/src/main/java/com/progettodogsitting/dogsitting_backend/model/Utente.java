package com.progettodogsitting.dogsitting_backend.model;

import jakarta.persistence.*;
import lombok.Data;

// Annotazione Lombok per generare getter, setter, toString, equals e hashCode
@Data
// Specifica che questa classe è un'entità JPA mappata su database
@Entity
// Specifica il nome della tabella corrispondente nel database
@Table(name = "utente")
// Usa la strategia JOINED per l'ereditarietà: una tabella per Utente e tabelle separate per le sottoclassi
@Inheritance(strategy = InheritanceType.JOINED)
public class Utente {

    // Identifica la chiave primaria della tabella
    @Id
    // Specifica il mapping sulla colonna "username" e che non può essere nulla
    @Column(name = "username", nullable = false)
    private String username;

    // Colonna per il nome di battesimo
    @Column(name = "nome_batt", nullable = false)
    private String nomeBattesimo;

    // Colonna per il cognome
    @Column(name = "cognome", nullable = false)
    private String cognome;

    // Colonna per il codice di avviamento postale
    @Column(name = "cap", nullable = false)
    private String cap;

    // Colonna per il numero civico
    @Column(name = "n_civico", nullable = false)
    private String nCivico;

    // Colonna per la provincia
    @Column(name = "provincia", nullable = false)
    private String provincia;

    // Colonna per la via di residenza
    @Column(name = "via", nullable = false)
    private String via;

    // Colonna per il numero di telefono
    @Column(name = "n_tel", nullable = false)
    private String nTel;

    // Colonna per memorizzare la password utente
    @Column(name = "password", nullable = false)
    private String password;

    // Indica che questo attributo non deve essere persistito sul DB (usato solo a runtime)
    @Transient 
    private String ruolo;
}
