package com.progettodogsitting.dogsitting_backend.model;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;

@Data
@Embeddable
@NoArgsConstructor 
@AllArgsConstructor
public class LezioneId implements Serializable {


    @Column(name = "nome_campo")
    private String nomeCampo;

    @Column(name = "ora")
    private LocalTime ora;

    @Column(name = "data")
    private LocalDate data;
}