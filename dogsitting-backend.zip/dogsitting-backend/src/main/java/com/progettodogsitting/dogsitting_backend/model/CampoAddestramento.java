package com.progettodogsitting.dogsitting_backend.model;

import jakarta.persistence.*;
import lombok.Data;

// Rappresenta i dati dei vari campi per l'addestramento
@Data
@Entity
@Table(name = "campo_addestramento")
public class CampoAddestramento {

    // Nome del campo come identificatore univoco
    @Id
    @Column(name = "nome", nullable = false)
    private String nome;

    // Indirizzo: via
    @Column(name = "via", nullable = false)
    private String via;

    // Indirizzo: numero civico
    @Column(name = "n_civico", nullable = false)
    private String nCivico;

    // Indirizzo: CAP
    @Column(name = "cap", nullable = false)
    private String cap;

    // Indirizzo: provincia
    @Column(name = "provincia", nullable = false)
    private String provincia;

    // Contatto telefonico
    @Column(name = "n_tel", nullable = false)
    private String nTel;

    // Orario di apertura quotidiano
    @Column(name = "orario_apertura", nullable = false)
    private String orarioApertura; // Es. 08:00 – 19:00
}
