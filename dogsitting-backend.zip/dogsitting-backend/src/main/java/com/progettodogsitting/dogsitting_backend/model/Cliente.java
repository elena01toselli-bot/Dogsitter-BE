package com.progettodogsitting.dogsitting_backend.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

// Annotazione Lombok per i metodi di accesso ai dati
@Data
// Genera equals e hashCode chiamando anche i metodi della superclasse (Utente)
@EqualsAndHashCode(callSuper = true)
// Indica che questa è un'entità gestita da JPA
@Entity
// Mappa questa classe sulla tabella "cliente"
@Table(name = "cliente")
// Collega la chiave primaria di questa tabella alla chiave primaria di Utente ("username")
@PrimaryKeyJoinColumn(name = "username")
public class Cliente extends Utente {
    // Questa classe eredita tutti i campi da Utente e non definisce attributi aggiuntivi
}
