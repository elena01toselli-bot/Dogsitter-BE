package com.progettodogsitting.dogsitting_backend.service;

import com.progettodogsitting.dogsitting_backend.DTO.OffreDTO;
import com.progettodogsitting.dogsitting_backend.model.Offre;
import com.progettodogsitting.dogsitting_backend.model.OffreId;
import com.progettodogsitting.dogsitting_backend.repository.DogsitterRepository;
import com.progettodogsitting.dogsitting_backend.repository.OffreRepository;
import com.progettodogsitting.dogsitting_backend.repository.ServizioRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

// Classe per gestire le logiche di ServizioOfferto
@Service
public class ServizioService {

    // Inietta il layer repository
    @Autowired
    private OffreRepository repository;

    @Autowired
    private DogsitterRepository dogsitterRepository;

    @Autowired
    private ServizioRepository servizioRepository;

    private Offre convertToEntity(OffreDTO dto) {

        Offre offre = new Offre();
     
        offre.setId(new OffreId(dto.getUsernameDogsitter(), dto.getIdServizio()));

        offre.setDogsitter(dogsitterRepository.findById(dto.getUsernameDogsitter()).orElse(null));
        offre.setServizio(servizioRepository.findById(dto.getIdServizio()).orElse(null));

        offre.setPrezzoListino(dto.getPrezzoListino());
     
        return offre;
    }

    private OffreDTO convertToDTO(Offre offre) {
        
        OffreDTO dto = new OffreDTO();
        
        dto.setIdServizio(offre.getId().getIdServizio());
        dto.setUsernameDogsitter(offre.getId().getUsernameDogsitter());
        dto.setCategoria(offre.getServizio().getCategoria());
        dto.setDurata(offre.getServizio().getDurata());
        dto.setPrezzoListino(offre.getPrezzoListino());
        
        return dto;
    }

    // Ritorna la lista dei servizi offerti da un determinato dogsitter
    public List<OffreDTO> findByDogsitter(String usernameDogsitter) {

        List<Offre> offerte = repository.findByDogsitter_Username(usernameDogsitter);

        return offerte.stream().map(this::convertToDTO).toList();
    }

    // Cerca un servizio per ID primario
    public Optional<OffreDTO> findById(Integer id) {
        
        return repository.findById(id).map(this::convertToDTO);
    }

    // Salva o aggiorna un ServizioOfferto nel database
    public OffreDTO save(OffreDTO offre) {
        

        Offre entity = convertToEntity(offre);
        
        Offre savedEntity = repository.save(entity);

        return convertToDTO(savedEntity);
    }

    // Elimina il record
    public void deleteById(Integer id) {
        repository.deleteById(id);
    }
}
