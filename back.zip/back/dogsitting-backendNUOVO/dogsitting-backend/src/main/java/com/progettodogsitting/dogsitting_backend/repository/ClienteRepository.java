package com.progettodogsitting.dogsitting_backend.repository;

import com.progettodogsitting.dogsitting_backend.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

// Interfaccia Spring Data per l'accesso al database della tabella cliente
@Repository
public interface ClienteRepository extends JpaRepository<Cliente, String> {
    // I metodi standard (save, delete, findAll) sono implementati automaticamente
}
