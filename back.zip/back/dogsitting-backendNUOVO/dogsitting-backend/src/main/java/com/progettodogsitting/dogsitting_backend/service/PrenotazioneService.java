package com.progettodogsitting.dogsitting_backend.service;

import com.progettodogsitting.dogsitting_backend.DTO.PrenotazioneDTO;
import com.progettodogsitting.dogsitting_backend.model.EsecuzioneServizio;
import com.progettodogsitting.dogsitting_backend.model.LezioneId;
import com.progettodogsitting.dogsitting_backend.model.Prenotazione;
import com.progettodogsitting.dogsitting_backend.repository.CaneRepository;
import com.progettodogsitting.dogsitting_backend.repository.DogsitterRepository;
import com.progettodogsitting.dogsitting_backend.repository.EsecuzioneServizioRepository;
import com.progettodogsitting.dogsitting_backend.repository.LezioneRepository;
import com.progettodogsitting.dogsitting_backend.repository.PrenotazioneRepository;
import com.progettodogsitting.dogsitting_backend.repository.ServizioRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

// Classe servizio per incapsulare le logiche di prenotazione
@Service
public class PrenotazioneService {

    // Repository che interfaccerà il DB
    @Autowired
    private PrenotazioneRepository repository;    
    @Autowired
    private EsecuzioneServizioRepository esecuzioneServizioRepository;

    @Autowired
    private CaneRepository caneRepository;

    @Autowired
    private ServizioRepository servizioRepository;

    @Autowired
    private DogsitterRepository dogsitterRepository;

    @Autowired
    private LezioneRepository lezioneRepository;




    private PrenotazioneDTO convertToDTO(Prenotazione prenotazione) {
     
        PrenotazioneDTO dto = new PrenotazioneDTO();
     
        dto.setCodiceId(prenotazione.getCodiceId());
        dto.setPrezzoPattuito(prenotazione.getPrezzoPattuito());
        dto.setNMicrochip(prenotazione.getCane().getNMicrochip());
        dto.setNomeCane(prenotazione.getCane().getNome());
        dto.setCategoriaPrenotazione(prenotazione.getCane().getCliente().getUsername());

        if (prenotazione.getTipologiaAttivita().equalsIgnoreCase("lezione")) {

            dto.setDataSvolgimento(prenotazione.getLezione().getId().getData());
            dto.setOraSvolgimento(prenotazione.getLezione().getId().getOra());
            dto.setNomeCampo(prenotazione.getLezione().getCampoAddestramento().getNome());  
            dto.setCategoriaPrenotazione(prenotazione.getTipologiaAttivita());      

        }
        else if (prenotazione.getTipologiaAttivita().equalsIgnoreCase("dogsitting")) {

            // Per il dogsitting, i dettagli specifici sono nella tabella EsecuzioneServizio
            EsecuzioneServizio esecuzione = esecuzioneServizioRepository.findById(prenotazione.getCodiceId())
                .orElseThrow(() -> new RuntimeException("EsecuzioneServizio non trovata per prenotazione ID: " + prenotazione.getCodiceId()));

            dto.setDataSvolgimento(esecuzione.getDataSvolgimento());
            dto.setOraSvolgimento(esecuzione.getOraSvolgimento());
            dto.setCategoriaPrenotazione(prenotazione.getTipologiaAttivita());
            dto.setCategoriaServizio(esecuzione.getServizio().getCategoria());
            dto.setIdServizio(esecuzione.getServizio().getId());
            dto.setUsernameDogsitter(esecuzione.getDogsitter().getUsername());        
        }
        else {
            // Se la tipologia è sconosciuta, puoi decidere come gestirla  lancio un'eccezione 
            throw new IllegalArgumentException("Tipologia di attività sconosciuta");
        }

        return dto;
    }


    // Ritorna tutte le prenotazioni in cui è coinvolto un dato cliente
    public List<PrenotazioneDTO> findByCliente(String usernameCliente) {

        List<Prenotazione> prenotazioniCliente = repository.findByCane_Cliente_UsernameAndTipologiaAttivita(usernameCliente, "lezione");

        List<PrenotazioneDTO> prenotazioni =new ArrayList<>();

        for (Prenotazione pren : prenotazioniCliente) {
            
            try {
                prenotazioni.add(convertToDTO(pren));                   
            } catch (Exception e) {
                // Log dell'errore e continua con la prossima prenotazione
                System.err.println("Errore nella conversione della prenotazione con ID " + pren.getCodiceId() + ": " + e.getMessage());

            }
        
        }
        
        return prenotazioni;
    }

    // Ritorna tutte le prenotazioni relative a un dato dogsitter
    public List<PrenotazioneDTO> findByDogsitter(String usernameDogsitter) {

        List<Prenotazione> prenotazioniDogsitter = repository.findByDogsitterUsername(usernameDogsitter);
        List<PrenotazioneDTO> prenotazioni =new ArrayList<>();

        for (Prenotazione pren : prenotazioniDogsitter) {
            
                prenotazioni.add(convertToDTO(pren));
        }
        return prenotazioni;
    }

    // Trova la prenotazione per ID univoco (codice)
    public Optional<PrenotazioneDTO> findByCodiceId(Integer id) {

        return Optional.of(convertToDTO(repository.findByCodiceId(id).orElseThrow(() -> new RuntimeException("Prenotazione non trovata per ID: " + id))));
    }

    // Salva i dati della prenotazione
    public PrenotazioneDTO save(PrenotazioneDTO prenotazione, boolean modifica) {
 
        // se è dogsitter allora messaggio:
        //usernameCliente: this.session.getUsername() ?? '',
        // usernameDogsitter
        // prezzoPattuito
        // idServizio
        // categoriaPrenotazione: 'dogsitter',
        // dataSvolgimento
        // oraSvolgimento
        // nMicrochip
        // codiceId

        Prenotazione prenotazioneEntity = new Prenotazione();

        if (modifica) {

            prenotazioneEntity.setCodiceId(prenotazione.getCodiceId());

        }

        prenotazioneEntity.setPrezzoPattuito(prenotazione.getPrezzoPattuito());
        prenotazioneEntity.setCane(caneRepository.findById(prenotazione.getNMicrochip())
            .orElseThrow(() -> new RuntimeException("Cane non trovato per microchip: " + prenotazione.getNMicrochip())));

        if(prenotazione.getCategoriaPrenotazione().equalsIgnoreCase("dogsitter")) {

            // logica per creare una prenotazione di dogsitting
            // 1. Crea la prenotazione con i dati base
            // 2. Crea l'esecuzione del servizio associata alla prenotazione
            // 3. Salva entrambi nel database e ritorna il DTO con i dati completi
            
            prenotazioneEntity.setTipologiaAttivita("dogsitter");
        
            // salvo la prenotazione per generare l'ID
            Prenotazione savedPrenotazione = repository.save(prenotazioneEntity);

            if (savedPrenotazione == null) {
                throw new RuntimeException("Errore durante il salvataggio della prenotazione di dogsitting");
            }

            EsecuzioneServizio esecuzione = new EsecuzioneServizio();

            esecuzione.setCodiceIdPren(savedPrenotazione.getCodiceId()); // Associa l'esecuzione alla prenotazione tramite lo stesso ID
            esecuzione.setDataSvolgimento(prenotazione.getDataSvolgimento());
            esecuzione.setOraSvolgimento(prenotazione.getOraSvolgimento());
            esecuzione.setPrenotazione(savedPrenotazione);
            esecuzione.setServizio(servizioRepository.findById(prenotazione.getIdServizio())
                .orElseThrow(() -> new RuntimeException("Servizio non trovato per ID: " + prenotazione.getIdServizio())));
            esecuzione.setDogsitter(dogsitterRepository.findById(prenotazione.getUsernameDogsitter())
                .orElseThrow(() -> new RuntimeException("Dogsitter non trovato per username: " + prenotazione.getUsernameDogsitter())));

            EsecuzioneServizio esecuzionesaved = esecuzioneServizioRepository.save(esecuzione);
            
            if (esecuzionesaved == null) {
                throw new RuntimeException("Errore durante il salvataggio dell'esecuzione del servizio per la prenotazione ID: " + savedPrenotazione.getCodiceId());
            }


            return convertToDTO(savedPrenotazione);
        }
    

        //se invece è lezione allora messaggio:
        //   usernameCliente: this.session.getUsername() ?? '',
        //   nomeCampo:       this.campo?.nome ?? '',
        //   dataSvolgimento: this.giornoSelezionato?.data.toISOString().split('T')[0] ?? '', // "YYYY-MM-DD"
        //   oraSvolgimento:  this.prenotazione.orario,
        //   nMicrochip:      this.prenotazione.nMicrochipCane,
        //   categoriaPrenotazione: 'lezione',
        //   prezzoPattuito:  this.lezioneSelezionata?.costo ?? 0,
        //   codiceId:        0  il database assegna l'ID

        if(prenotazione.getCategoriaPrenotazione().equalsIgnoreCase("lezione")) {

            // logica per creare una prenotazione di lezione
            // 1. Crea la prenotazione con i dati base

            prenotazioneEntity.setTipologiaAttivita("lezione");
            prenotazioneEntity.setLezione(lezioneRepository.findById(new LezioneId(prenotazione.getNomeCampo(), prenotazione.getOraSvolgimento(), prenotazione.getDataSvolgimento()))
                .orElseThrow(() -> new RuntimeException("Lezione non trovata per campo: " + prenotazione.getNomeCampo() + ", data: " + prenotazione.getDataSvolgimento() + ", ora: " + prenotazione.getOraSvolgimento())));

    
            Prenotazione savedPrenotazione = repository.save(prenotazioneEntity);

            if (savedPrenotazione == null) {
                throw new RuntimeException("Errore durante il salvataggio della prenotazione di lezione");
            }


            return convertToDTO(savedPrenotazione);    
        }
        
        else {
            throw new IllegalArgumentException("Categoria di prenotazione sconosciuta: " + prenotazione.getCategoriaPrenotazione());
        }
    }
    // Elimina la prenotazione associata a questo ID
    public void deleteByCodiceId(Integer id) {

        repository.deleteByCodiceId(id);
    }

}