package com.progettodogsitting.dogsitting_backend.service;

import com.progettodogsitting.dogsitting_backend.model.Cane;
import com.progettodogsitting.dogsitting_backend.repository.CaneRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

// Servizio che racchiude la logica applicativa per i cani
@Service
public class CaneService {

    // Repository iniettato
    @Autowired
    private CaneRepository repository;

    // Ritorna i cani appartenenti a un cliente specifico
    public List<Cane> findByCliente(String usernameCliente) {
        return repository.findByUsernameCliente(usernameCliente);
    }

    // Cerca un cane usando il suo numero di microchip
    public Optional<Cane> findById(String nMicrochip) {
        return repository.findById(nMicrochip);
    }

    // Inserisce o aggiorna le informazioni del cane
    public Cane save(Cane cane) {
        return repository.save(cane);
    }

    // Rimuove i dati di un cane in base al microchip
    public void deleteById(String nMicrochip) {
        repository.deleteById(nMicrochip);
    }
}
