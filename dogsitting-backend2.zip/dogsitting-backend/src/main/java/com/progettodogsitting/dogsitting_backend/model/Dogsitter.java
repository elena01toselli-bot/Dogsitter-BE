package com.progettodogsitting.dogsitting_backend.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.util.List;

// Annotazione Lombok per getter, setter ecc.
@Data
// Include i campi della superclasse nel calcolo di equals/hashCode
@EqualsAndHashCode(callSuper = true)
// Indica che questa è un'entità JPA
@Entity
// Mappa questa classe sulla tabella "dog_sitter"
@Table(name = "dog_sitter")
// Definisce la colonna "username" come foreign key verso la tabella padre Utente
@PrimaryKeyJoinColumn(name = "username")
public class Dogsitter extends Utente {

    // Specifica il limite massimo di cani che il dogsitter può gestire
    @Column(name = "max_cani", nullable = false)
    private Integer maxCani;

    // Indica che si tratta di una collezione di elementi stringa associati a questo dogsitter
    @ElementCollection
    // Definisce la tabella di join "giorni_dog_sitter" e la sua chiave esterna "username"
    @CollectionTable(name = "giorni_dog_sitter", joinColumns = @JoinColumn(name = "username"))
    // Nome della colonna in cui verranno salvati i giorni all'interno della collection table
    @Column(name = "giorno")
    private List<String> giorniDisponibili;

    // Collezione di elementi per definire le taglie dei cani gestibili
    @ElementCollection
    // Tabella esterna "taglie_cani" collegata all'username del dogsitter
    @CollectionTable(name = "taglie_cani", joinColumns = @JoinColumn(name = "username"))
    // Colonna contenente la stringa della taglia (es: grande, piccola)
    @Column(name = "taglia")
    private List<String> taglieCani;
}
