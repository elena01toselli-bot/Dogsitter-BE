package com.progettodogsitting.dogsitting_backend.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.progettodogsitting.dogsitting_backend.model.Cliente;
import com.progettodogsitting.dogsitting_backend.service.ClienteService;

// Controller REST per la gestione degli utenti di tipo Cliente
@RestController
@RequestMapping("/api/clienti")
@CrossOrigin(origins = "*")
public class ClienteController {

    // Servizio contenente la logica applicativa
    @Autowired
    private ClienteService service;

    // Metodo per ottenere tutti i clienti registrati
    @GetMapping
    public List<Cliente> getAll() {
        // Interroga il database tramite service
        return service.findAll();
    }

    // Metodo per trovare un cliente in base allo username
    @GetMapping("/{username}")
    public ResponseEntity<Cliente> getById(@PathVariable String username) {
        // Ricerca il cliente
        Optional<Cliente> cliente = service.findById(username);
        // Restituisce 200 OK se trovato, altrimenti 404
        return cliente.map(ResponseEntity::ok)
                      .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Metodo per aggiornare i dati di un cliente
    @PutMapping("/{username}")
    public ResponseEntity<Cliente> update(@PathVariable String username,
                                          @RequestBody Cliente cliente) {
        // Controlla se il record esiste
        if (!service.findById(username).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        // Forza l'username nel DTO uguale a quello dell'URL
        cliente.setUsername(username);
        // Salva le modifiche
        return ResponseEntity.ok(service.save(cliente));
    }

    // Metodo per rimuovere un cliente dal sistema
    @DeleteMapping("/{username}")
    public ResponseEntity<Void> delete(@PathVariable String username) {
        // Verifica se l'utente è presente
        if (!service.findById(username).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        // Cancella il cliente
        service.deleteById(username);
        return ResponseEntity.noContent().build();
    }
}
