package com.progettodogsitting.dogsitting_backend.controller;

import com.progettodogsitting.dogsitting_backend.model.ServizioOfferto;
import com.progettodogsitting.dogsitting_backend.service.ServizioOffertoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

// Controller REST per la gestione dei servizi offerti dai dogsitter
@RestController
@RequestMapping("/api/servizi")
@CrossOrigin(origins = "*")
public class ServizioController {

    // Servizio che incapsula la logica applicativa per i Servizi Offerti
    @Autowired
    private ServizioOffertoService service;

    // Ritorna le categorie di servizi fisse
    @GetMapping("/categorie")
    public List<String> getCategorie() {
        // Restituisce una lista di stringhe statiche
        return Arrays.asList("dogsitting", "addestramento", "toelettatura", "passeggiata", "pensione");
    }

    // Ritorna i servizi offerti da uno specifico dogsitter
    @GetMapping("/dogsitter/{usernameDogsitter}")
    public List<ServizioOfferto> getByDogsitter(@PathVariable String usernameDogsitter) {
        return service.findByDogsitter(usernameDogsitter);
    }

    // Crea un nuovo servizio offerto
    @PostMapping
    public ServizioOfferto create(@RequestBody ServizioOfferto servizio) {
        // Salva i dati del nuovo servizio offerto e li restituisce
        return service.save(servizio);
    }

    // Aggiorna un servizio offerto esistente usando l'ID
    @PutMapping("/{id}")
    public ResponseEntity<ServizioOfferto> update(@PathVariable Integer id,
                                                  @RequestBody ServizioOfferto servizio) {
        // Verifica l'esistenza prima di fare l'update
        Optional<ServizioOfferto> existing = service.findById(id);
        if (!existing.isPresent()) {
            return ResponseEntity.notFound().build();
        }
        // Esegue il salvataggio
        return ResponseEntity.ok(service.save(servizio));
    }

    // Cancella un servizio offerto dato il suo ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) {
        // Controlla se esiste per ritornare l'esito corretto
        if (!service.findById(id).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        // Cancella
        service.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
