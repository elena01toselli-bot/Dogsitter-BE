package com.progettodogsitting.dogsitting_backend.repository;

import com.progettodogsitting.dogsitting_backend.model.ServizioOfferto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

// Interfaccia per il CRUD sulla tabella OFFRE
@Repository
public interface ServizioOffertoRepository extends JpaRepository<ServizioOfferto, Integer> {
    
    // Trova tutti i servizi proposti da uno specifico dogsitter
    List<ServizioOfferto> findByUsernameDogsitter(String usernameDogsitter);
}
