package com.progettodogsitting.dogsitting_backend.model;

import jakarta.persistence.*;
import lombok.Data;

// Entità che mappa la tabella "servizio"
@Data
@Entity
@Table(name = "servizio")
public class Servizio {

    // Identificativo univoco autogenerato
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    // Categoria del servizio (es: passeggiata, toelettatura)
    @Column(name = "categoria", nullable = false)
    private String categoria;

    // Durata del servizio in minuti
    @Column(name = "durata", nullable = false)
    private Integer durata;
}
