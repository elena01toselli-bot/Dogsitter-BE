package com.progettodogsitting.dogsitting_backend.service;

import com.progettodogsitting.dogsitting_backend.model.ServizioOfferto;
import com.progettodogsitting.dogsitting_backend.repository.ServizioOffertoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

// Classe per gestire le logiche di ServizioOfferto
@Service
public class ServizioOffertoService {

    // Inietta il layer repository
    @Autowired
    private ServizioOffertoRepository repository;

    // Ritorna la lista dei servizi offerti da un determinato dogsitter
    public List<ServizioOfferto> findByDogsitter(String usernameDogsitter) {
        return repository.findByUsernameDogsitter(usernameDogsitter);
    }

    // Cerca un servizio per ID primario
    public Optional<ServizioOfferto> findById(Integer id) {
        return repository.findById(id);
    }

    // Salva o aggiorna un ServizioOfferto nel database
    public ServizioOfferto save(ServizioOfferto servizioOfferto) {
        return repository.save(servizioOfferto);
    }

    // Elimina il record
    public void deleteById(Integer id) {
        repository.deleteById(id);
    }
}
