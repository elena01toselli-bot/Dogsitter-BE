package com.progettodogsitting.dogsitting_backend.model;

import jakarta.persistence.*;
import lombok.Data;

// Entità che rappresenta una singola prenotazione per cani o lezioni
@Data
@Entity
@Table(name = "prenotazione")
public class Prenotazione {

    // ID testuale generato univocamente
    @Id
    @Column(name = "codice_id", nullable = false)
    private String codiceId;

    // Il costo accordato per la prestazione
    @Column(name = "prezzo_pattuito", nullable = false)
    private Double prezzoPattuito;

    // Tipo di prestazione (es. dog sitting, lezione di addestramento)
    @Column(name = "tipologia_attivita", nullable = false)
    private String tipologiaAttivita;

    // Ora di inizio della lezione
    @Column(name = "ora_lezione", nullable = false)
    private String oraLezione;

    // Data in cui si tiene la lezione
    @Column(name = "data_lezione", nullable = false)
    private String dataLezione;

    // Cane associato alla prenotazione
    @ManyToOne
    @JoinColumn(name = "n_microchip", nullable = false)
    private Cane cane;

    // Campo dove si terrà la lezione (opzionale se è solo dogsitting)
    @ManyToOne
    @JoinColumn(name = "nome_campo")
    private CampoAddestramento campoAddestramento;
}
