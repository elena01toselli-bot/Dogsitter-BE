package com.progettodogsitting.dogsitting_backend.service;

import com.progettodogsitting.dogsitting_backend.model.Lezione1;
import com.progettodogsitting.dogsitting_backend.repository.Lezione1Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

// Servizio per la gestione della logica di business di Lezione1
@Service
public class Lezione1Service {

    // Iniettiamo il repository per accedere al database
    @Autowired
    private Lezione1Repository repository;

    // Recupera tutte le tipologie di lezioni associate ai campi
    public List<Lezione1> findAll() {
        return repository.findAll();
    }

    // Recupera la configurazione (Lezione1) di un campo specifico (tramite la chiave PK nomeCampo)
    public Optional<Lezione1> findById(String nomeCampo) {
        return repository.findById(nomeCampo);
    }

    // Salva o aggiorna i dati
    public Lezione1 save(Lezione1 lezione) {
        return repository.save(lezione);
    }

    // Elimina i dati per un dato campo
    public void deleteById(String nomeCampo) {
        repository.deleteById(nomeCampo);
    }
}
