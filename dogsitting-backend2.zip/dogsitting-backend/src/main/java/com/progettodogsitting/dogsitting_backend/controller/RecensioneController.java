package com.progettodogsitting.dogsitting_backend.controller;

import com.progettodogsitting.dogsitting_backend.model.Recensione;
import com.progettodogsitting.dogsitting_backend.model.RecensioneId;
import com.progettodogsitting.dogsitting_backend.service.DogsitterService;
import com.progettodogsitting.dogsitting_backend.service.RecensioneService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Collectors;

// Controller REST per la gestione delle recensioni tra cliente e dogsitter
@RestController
@RequestMapping("/api/recensioni")
@CrossOrigin(origins = "*")
public class RecensioneController {

    // Servizio per la logica delle recensioni
    @Autowired
    private RecensioneService service;

    // Servizio per accedere ai dati dei dogsitter
    @Autowired
    private DogsitterService dogsitterService;

    // Ritorna tutte le recensioni ricevute da un dogsitter
    @GetMapping("/dogsitter/{usernameDogsitter}")
    public List<Recensione> getByDogsitter(@PathVariable String usernameDogsitter) {
        return service.findByDogsitter(usernameDogsitter);
    }

    // Ritorna tutte le recensioni scritte da un cliente
    @GetMapping("/cliente/{usernameCliente}")
    public List<Recensione> getByCliente(@PathVariable String usernameCliente) {
        return service.findByCliente(usernameCliente);
    }

    // Ritorna gli username dei dogsitter disponibili (che esistono nel sistema)
    @GetMapping("/dogsitter-disponibili")
    public List<String> getDogsitterDisponibili() {
        return dogsitterService.findAll()
                .stream()
                .map(d -> d.getUsername())
                .collect(Collectors.toList());
    }

    // Crea una nuova recensione
    @PostMapping
    public Recensione create(@RequestBody Recensione recensione) {
        // Validazione dei campi fondamentali
        if (recensione.getCliente() == null || recensione.getDogsitter() == null) {
            throw new IllegalArgumentException("Cliente e Dogsitter non possono essere null");
        }
        // Crea l'ID composto
        RecensioneId id = new RecensioneId(
            recensione.getCliente().getUsername(),
            recensione.getDogsitter().getUsername()
        );
        // Imposta l'ID e salva
        recensione.setId(id);
        return service.save(recensione);
    }

    // Aggiorna una recensione esistente
    @PutMapping
    public ResponseEntity<Recensione> update(@RequestBody Recensione recensione) {
        // Controlla che il payload sia valido e contenga l'ID
        if (recensione.getId() == null || recensione.getCliente() == null || recensione.getDogsitter() == null) {
            return ResponseEntity.badRequest().build();
        }
        // Identifica l'autore della recensione
        String usernameCliente = recensione.getCliente().getUsername();
        // Verifica se esistono recensioni per questo cliente (come controllo blando)
        if (!service.findByCliente(usernameCliente).isEmpty()) {
            return ResponseEntity.ok(service.save(recensione));
        }
        return ResponseEntity.notFound().build();
    }

    // Cancella una singola recensione specificando entrambi gli username
    @DeleteMapping("/{usernameDogsitter}/{usernameCliente}")
    public ResponseEntity<Void> delete(@PathVariable String usernameDogsitter,
                                       @PathVariable String usernameCliente) {
        // Esegue la cancellazione usando la PK composta
        service.deleteById(new RecensioneId(usernameCliente, usernameDogsitter));
        return ResponseEntity.noContent().build();
    }

    // Rimuove tutte le recensioni fatte da un cliente
    @DeleteMapping("/cliente/{usernameCliente}")
    public ResponseEntity<Void> deleteAllByCliente(@PathVariable String usernameCliente) {
        service.deleteAllByCliente(usernameCliente);
        return ResponseEntity.noContent().build();
    }
}
