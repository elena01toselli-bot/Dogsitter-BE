package com.progettodogsitting.dogsitting_backend.repository;

import com.progettodogsitting.dogsitting_backend.model.Prenotazione;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

// Mapping sulla tabella PRENOTAZIONE
@Repository
public interface PrenotazioneRepository extends JpaRepository<Prenotazione, String> {
    
    // Trova la prenotazione partendo dal suo id di tipo stringa
    Optional<Prenotazione> findByCodiceId(String codiceId);
    
    // Metodo per cancellare la prenotazione dal codice
    void deleteByCodiceId(String codiceId);
    
    // Restituisce le prenotazioni filtrandole in base allo username del cliente che possiede il cane
    List<Prenotazione> findByUsernameCliente(String usernameCliente);
    
    // Restituisce le prenotazioni filtrandole in base al dogsitter
    List<Prenotazione> findByUsernameDogsitter(String usernameDogsitter);
}
