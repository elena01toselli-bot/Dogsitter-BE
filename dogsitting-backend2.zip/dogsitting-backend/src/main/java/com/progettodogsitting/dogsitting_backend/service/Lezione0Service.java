package com.progettodogsitting.dogsitting_backend.service;

import com.progettodogsitting.dogsitting_backend.model.Lezione0;
import com.progettodogsitting.dogsitting_backend.model.Lezione0Id;
import com.progettodogsitting.dogsitting_backend.repository.Lezione0Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

// Servizio per la gestione della logica di business di Lezione0
@Service
public class Lezione0Service {

    // Iniettiamo il repository per accedere al database
    @Autowired
    private Lezione0Repository repository;

    // Recupera tutte le lezioni di un campo
    public List<Lezione0> findByCampo(String nomeCampo) {
        return repository.findByIdNomeCampo(nomeCampo);
    }

    // Recupera una lezione specifica in base al suo ID composto
    public Optional<Lezione0> findById(Lezione0Id id) {
        return repository.findById(id);
    }

    // Salva o aggiorna una lezione
    public Lezione0 save(Lezione0 lezione) {
        return repository.save(lezione);
    }

    // Elimina una lezione in base al suo ID
    public void deleteById(Lezione0Id id) {
        repository.deleteById(id);
    }
}
