package com.progettodogsitting.dogsitting_backend.service;

import com.progettodogsitting.dogsitting_backend.model.Prenotazione;
import com.progettodogsitting.dogsitting_backend.repository.PrenotazioneRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

// Classe servizio per incapsulare le logiche di prenotazione
@Service
public class PrenotazioneService {

    // Repository che interfaccerà il DB
    @Autowired
    private PrenotazioneRepository repository;

    // Ritorna tutte le prenotazioni in cui è coinvolto un dato cliente
    public List<Prenotazione> findByCliente(String usernameCliente) {
        return repository.findByUsernameCliente(usernameCliente);
    }

    // Ritorna tutte le prenotazioni relative a un dato dogsitter
    public List<Prenotazione> findByDogsitter(String usernameDogsitter) {
        return repository.findByUsernameDogsitter(usernameDogsitter);
    }

    // Trova la prenotazione per ID univoco (codice)
    public Optional<Prenotazione> findByCodiceId(String id) {
        return repository.findByCodiceId(id);
    }

    // Salva i dati della prenotazione
    public Prenotazione save(Prenotazione prenotazione) {
        return repository.save(prenotazione);
    }

    // Elimina la prenotazione associata a questo ID
    public void deleteByCodiceId(String id) {
        repository.deleteByCodiceId(id);
    }
}
