package com.progettodogsitting.dogsitting_backend.model;

import jakarta.persistence.*;
import lombok.Data;

// Entità che mappa la tabella LEZIONE_1 del database
// Indica la tipologia di lezioni di un campo di addestramento e il max partecipanti
@Data
@Entity
@Table(name = "lezione_1")
public class Lezione1 {

    // La chiave primaria è direttamente il nome del campo
    @Id
    @Column(name = "nome_campo", nullable = false)
    private String nomeCampo;

    // FK verso le tipologie disponibili (es. agility, obbedienza)
    @ManyToOne
    @JoinColumn(name = "tipologia", nullable = false)
    private TipologiaLezione tipologia;

    // Numero massimo di cani o persone ammesse per questo campo in questa tipologia
    @Column(name = "max_partecipanti", nullable = false)
    private Integer maxPartecipanti;

    // Riferimento al campo di addestramento in sola lettura
    @ManyToOne
    @JoinColumn(name = "nome_campo", insertable = false, updatable = false)
    private CampoAddestramento campo;
}
