package com.progettodogsitting.dogsitting_backend.model;

import jakarta.persistence.*;
import lombok.Data;

// Elenco delle possibili discipline per l'addestramento
@Data
@Entity
@Table(name = "tipologie_lezioni")
public class TipologiaLezione {

    // Nome della tipologia di lezione usata come identificatore
    @Id
    @Column(name = "tipologia", nullable = false)
    private String tipologia;

    // Prezzo prestabilito per questa disciplina
    @Column(name = "costo", nullable = false)
    private Double costo;
}
