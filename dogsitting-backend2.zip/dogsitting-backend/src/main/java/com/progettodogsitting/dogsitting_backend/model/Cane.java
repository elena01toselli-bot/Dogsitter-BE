package com.progettodogsitting.dogsitting_backend.model;

import jakarta.persistence.*;
import lombok.Data;

// Entità che mappa la tabella "cane"
@Data
@Entity
@Table(name = "cane")
public class Cane {

    // Identificativo univoco (microchip) come chiave primaria
    @Id
    @Column(name = "n_microchip", nullable = false)
    private String nMicrochip;

    // Nome del cane
    @Column(name = "nome", nullable = false)
    private String nome;

    // Razza del cane
    @Column(name = "razza", nullable = false)
    private String razza;

    // Taglia del cane
    @Column(name = "taglia", nullable = false)
    private String taglia;

    // Data di nascita salvata come stringa
    @Column(name = "data_nascita")
    private String dataNascita;

    // Note opzionali sul comportamento
    @Column(name = "note_comportamento")
    private String noteComportamento;

    // Relazione ManyToOne con Cliente (proprietario del cane)
    @ManyToOne
    @JoinColumn(name = "username_cliente", nullable = false)
    private Cliente cliente;
}
