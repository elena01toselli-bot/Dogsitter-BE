package com.progettodogsitting.dogsitting_backend.repository;

import com.progettodogsitting.dogsitting_backend.model.Cane;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

// Interfaccia per accesso diretto alla tabella CANE nel database
@Repository
public interface CaneRepository extends JpaRepository<Cane, String> {
    
    // Metodo speciale (JPA lo traduce in query automaticamente) per filtrare per utente
    List<Cane> findByUsernameCliente(String usernameCliente);
}
