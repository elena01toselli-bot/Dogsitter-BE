package com.progettodogsitting.dogsitting_backend.model;

import jakarta.persistence.*;
import lombok.Data;

// Entità che mappa la tabella LEZIONE_0 del database
// Rappresenta una singola lezione programmata in un campo di addestramento
@Data
@Entity
@Table(name = "lezione_0")
public class Lezione0 {

    // Utilizziamo un ID composto formato da nomeCampo, ora e data
    @EmbeddedId
    private Lezione0Id id;

    // Riferimento al campo di addestramento in sola lettura (i campi sono gestiti nell'ID)
    @ManyToOne
    @JoinColumn(name = "nome_campo", insertable = false, updatable = false)
    private CampoAddestramento campo;
}
